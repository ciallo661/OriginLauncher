﻿; Departure Launcher 瀹夎鍖呰剼鏈?
; 浣跨敤 Inno Setup 缂栬瘧: ISCC.exe installer.iss

#define MyAppName "Origin Launcher"
#define MyAppVersion "0.9.24"
#define MyAppPublisher "Origin"
#define MyAppExeName "OriginLauncher.exe"

[Setup]
AppId={{B7E3A2C1-4D5F-4A8E-9C2B-1F3D6E8A0B2C}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=installer
OutputBaseFilename=OriginLauncher-Setup-v{#MyAppVersion}
; SetupIconFile=icon.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#MyAppExeName}
AppCopyright=Copyright (C) 2026 Origin

[Languages]
Name: "chinesesimp"; MessagesFile: "compiler:Languages\ChineseSimplified.isl"

[Tasks]
Name: "desktopicon"; Description: "鍒涘缓妗岄潰蹇嵎鏂瑰紡"; GroupDescription: "闄勫姞鍥炬爣:"

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "icon.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\icon.ico"
Name: "{group}\鍗歌浇 {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\icon.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "绔嬪嵆鍚姩 {#MyAppName}"; Flags: nowait postinstall skipifsilent



























