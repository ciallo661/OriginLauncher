from PIL import Image

img = Image.open(r'C:\Users\pc\Desktop\9c186967-289b-4114-9b6f-50c27a3e3069_57x57.png').convert('RGBA')
data = img.getdata()

new_data = []
for item in data:
    # 白色或接近白色的像素变透明
    if item[0] > 240 and item[1] > 240 and item[2] > 240:
        new_data.append((255, 255, 255, 0))
    else:
        new_data.append(item)

img.putdata(new_data)
img.save('download_icon.png')
print('Done, saved to download_icon.png')
