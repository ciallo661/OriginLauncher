import os
# 禁用 PyInstaller 6.x onefile 父进程 PID 安全检查，避免更新启动时报 "PID not found" 错误
os.environ["PYINSTALLER_ONEFILE_PARENT_PID_CHECK"] = "0"
