# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [('icon.png', '.'), ('icon.ico', '.'), ('settings_icon.png', '.'), ('expand_btn.png', '.'), ('toast_bg.png', '.'), ('btn_close_normal.png', '.'), ('btn_close_hover.png', '.'), ('btn_main_min_normal.png', '.'), ('btn_main_min_pressed.png', '.'), ('btn_main_close_normal.png', '.'), ('btn_main_close_pressed.png', '.'), ('info_icon.png', '.'), ('wifi_icon.png', '.'), ('user_icon.png', '.'), ('external_icon.png', '.'), ('download_icon.png', '.'), ('disconnect_icon.png', '.'), ('premium_icon.png', '.'), ('chat_icon.png', '.')]
binaries = []
hiddenimports = []
tmp_ret = collect_all('PIL')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['mc_launcher.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=['runtime_hook.py'],
    excludes=['PIL.avif', 'PIL._avif'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='OriginLauncher',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    version='version_info.txt',
    icon=['icon.ico'],
)
