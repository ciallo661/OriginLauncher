# -*- coding: utf-8 -*-
"""生成 Origin Launcher 所需的界面图标 (透明背景 + 黑色线条, 与现有图标风格一致)

生成:
    download_icon.png    向下箭头(下载)
    disconnect_icon.png  断开的链条(离线登录 / 断开连接)

用法:
    python make_icons.py [输出目录]
"""
import os
import sys
import math

from PIL import Image, ImageDraw

SIZE = 512          # 最终尺寸
SS = 4              # 超采样倍数
S = SIZE * SS
BLACK = (26, 26, 26, 255)   # 与界面文字同色 #1a1a1a


def _stroke() -> int:
    """统一线宽(最终 512 画布上约 44px, 缩到 20px 约 1.7px)"""
    return 44 * SS


def _line(draw, pts, width):
    """带圆头圆角的折线"""
    draw.line(pts, fill=BLACK, width=width, joint="curve")
    r = width // 2
    for x, y in (pts[0], pts[-1]):
        draw.ellipse((x - r, y - r, x + r, y + r), fill=BLACK)


def make_download() -> Image.Image:
    """向下箭头 + 底部托盘线: 经典下载图标"""
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    w = _stroke()

    # 竖线
    _line(d, [(S * 0.5, S * 0.20), (S * 0.5, S * 0.70)], w)
    # 箭头两翼
    _line(d, [(S * 0.27, S * 0.49), (S * 0.5, S * 0.72)], w)
    _line(d, [(S * 0.73, S * 0.49), (S * 0.5, S * 0.72)], w)
    # 底部托盘横线
    _line(d, [(S * 0.23, S * 0.84), (S * 0.77, S * 0.84)], w)
    return img.resize((SIZE, SIZE), Image.LANCZOS)


def _ring(w, h, radius, stroke):
    """返回一个圆角矩形环(链条的一节), 画布大小按 w x h 留白"""
    canvas = (w + stroke * 2, h + stroke * 2)
    im = Image.new("RGBA", canvas, (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle(
        (stroke // 2, stroke // 2, stroke // 2 + w, stroke // 2 + h),
        radius=radius, outline=BLACK, width=stroke)
    return im


def _paste_link(base, cx, cy, w, h, radius, stroke, angle=-45):
    ring = _ring(w, h, radius, stroke).rotate(angle, resample=Image.BICUBIC, expand=True)
    base.alpha_composite(ring, (int(cx - ring.width / 2), int(cy - ring.height / 2)))


def make_disconnect() -> Image.Image:
    """两节断开的链条, 沿 45 度对角线摆放(断开连接)"""
    u = S / 512.0                      # 以 512 画布为单位
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    w = int(52 * u)                    # 线宽
    lw, lh = int(230 * u), int(150 * u)
    lr = lh // 2
    gap = 55 * u
    half = (lw + gap) / 2.0
    k = 0.70710678
    centers = [(S / 2 - half * k, S / 2 + half * k),
               (S / 2 + half * k, S / 2 - half * k)]
    for cx, cy in centers:
        _paste_link(img, cx, cy, lw, lh, lr, w)
    # 裁掉透明边并统一放大到画布 92%, 保证小尺寸下图标足够大
    bbox = img.getchannel("A").point(lambda a: 255 if a > 8 else 0).getbbox()
    if bbox:
        img = img.crop(bbox)
        target = int(S * 0.92)
        scale = min(target / img.width, target / img.height)
        img = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))), Image.LANCZOS)
        canvas = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        canvas.alpha_composite(img, ((S - img.width) // 2, (S - img.height) // 2))
        img = canvas
    return img.resize((SIZE, SIZE), Image.LANCZOS)


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
    os.makedirs(out, exist_ok=True)
    make_download().save(os.path.join(out, "download_icon.png"))
    make_disconnect().save(os.path.join(out, "disconnect_icon.png"))
    print("written to", out)


if __name__ == "__main__":
    main()
