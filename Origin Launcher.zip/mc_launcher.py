# -*- coding: utf-8 -*-
"""
Origin Launcher —— 圆角 Minecraft 启动器
特性:
  * 无边框圆角窗口(自绘圆角 + 自定义标题栏 + 拖拽)
  * 自动扫描本地 .minecraft 已安装版本
  * 用户名 / 内存分配 / Java 路径 / 游戏目录设置
  * 基础离线启动(解析版本 json, 拼接本地已下载库文件)
  * 启动日志实时输出

说明: 当前为基础版, 支持离线启动本地已下载完毕的版本;
      在线下载新版本 / 资源文件同步等能力将在后续版本中加入。
"""

import ctypes
import json
import math
import os
import subprocess
import sys
import urllib.request
import tempfile
import shutil
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

APP_NAME = "Origin Launcher"
APP_VERSION = "0.9.24"
DEFAULT_USER = "Steve"
GITHUB_REPO = "ciallo661/OriginLauncher"
GITHUB_API = "https://api.github.com/repos/" + GITHUB_REPO + "/releases/latest"


def resource_path(relative_path):
    """获取资源文件路径, 兼容 PyInstaller 打包后的临时目录"""
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)

TRANSPARENT = "#010203"          # 窗口 colorkey 透明色
BG_MAIN = "#ffffff"              # 主背景
BG_PANEL = "#f5f5f5"             # 面板背景
BG_HEADER = "#f8f8f8"            # 标题栏背景
ACCENT = "#000000"               # 主强调绿
ACCENT_HOVER = "#333333"
ACCENT_DARK = "#000000"
DANGER = "#e5533c"
DANGER_HOVER = "#f06a52"
TEXT = "#1a1a1a"
TEXT_DIM = "#666666"
BORDER = "#dddddd"
RADIUS = 15                      # 窗口圆角半径
LOGGER_BG = "#f0f0f0"


def enable_dpi_awareness():
    """启用 Windows DPI 感知, 避免高分屏模糊"""
    try:
        # PROCESS_PER_MONITOR_DPI_AWARE = 2
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def round_rect_points(x1, y1, x2, y2, r):
    """生成圆角矩形的贝塞尔控制点(用于 Canvas polygon smooth)"""
    return [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
        x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]


def round_rect_top_points(x1, y1, x2, y2, r):
    """生成仅顶部两角圆角、底部直角的矩形控制点(用于标题栏)"""
    return [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2, x1, y2, x1, y1 + r, x1, y1,
    ]


def round_rect_top_fine(x1, y1, x2, y2, r, segments=16):
    """生成顶部圆角(多段直线精确近似)、底部平直的多边形点列表, 不用 smooth 避免抗锯齿杂色"""
    pts = []
    # 顶部直边
    pts.append((x1 + r, y1))
    pts.append((x2 - r, y1))
    # 右上角圆弧 (从正上方 -90° 到正右方 0°)
    cx, cy = x2 - r, y1 + r
    for i in range(1, segments + 1):
        a = -math.pi / 2 + (math.pi / 2) * (i / segments)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    # 右侧直边到底部
    pts.append((x2, y2))
    # 底部直边
    pts.append((x1, y2))
    # 左侧直边到圆角起点
    pts.append((x1, y1 + r))
    # 左上角圆弧 (从正左方 180° 到正上方 -90°/270°)
    cx, cy = x1 + r, y1 + r
    for i in range(1, segments + 1):
        a = math.pi + (math.pi / 2) * (i / segments)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    # 展平为 [x1,y1,x2,y2,...]
    flat = []
    for px, py in pts:
        flat.append(px)
        flat.append(py)
    return flat


def round_rect_fine(x1, y1, x2, y2, r, segments=16):
    """生成四角都圆角的多边形点列表(多段直线精确近似, 比 smooth 更圆润)"""
    pts = []
    # 顶部直边
    pts.append((x1 + r, y1))
    pts.append((x2 - r, y1))
    # 右上角圆弧
    cx, cy = x2 - r, y1 + r
    for i in range(1, segments + 1):
        a = -math.pi / 2 + (math.pi / 2) * (i / segments)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    # 右侧直边
    pts.append((x2, y2 - r))
    # 右下角圆弧
    cx, cy = x2 - r, y2 - r
    for i in range(1, segments + 1):
        a = (math.pi / 2) * (i / segments)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    # 底部直边
    pts.append((x2 - r, y2))
    pts.append((x1 + r, y2))
    # 左下角圆弧
    cx, cy = x1 + r, y2 - r
    for i in range(1, segments + 1):
        a = math.pi / 2 + (math.pi / 2) * (i / segments)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    # 左侧直边
    pts.append((x1, y1 + r))
    # 左上角圆弧
    cx, cy = x1 + r, y1 + r
    for i in range(1, segments + 1):
        a = math.pi + (math.pi / 2) * (i / segments)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    # 展平
    flat = []
    for px, py in pts:
        flat.append(px)
        flat.append(py)
    return flat


def default_minecraft_dir():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, ".minecraft")


def scan_versions(mc_dir):
    """扫描 .minecraft/versions 下已安装的版本"""
    vdir = os.path.join(mc_dir, "versions")
    if not os.path.isdir(vdir):
        return []
    found = set()
    for name in os.listdir(vdir):
        p = os.path.join(vdir, name)
        if os.path.isdir(p):
            jar = os.path.join(p, name + ".jar")
            jf = os.path.join(p, name + ".json")
            if os.path.exists(jar) or os.path.exists(jf):
                found.add(name)
        elif name.endswith(".json"):
            try:
                with open(p, encoding="utf-8") as f:
                    found.add(json.load(f).get("id", name[:-5]))
            except Exception:
                found.add(name[:-5])
    return sorted(found, reverse=True)


def maven_lib_path(coord, mc_dir):
    """把 maven 坐标转为本地 libraries 路径"""
    parts = coord.split(":")
    if len(parts) < 3:
        return ""
    group, artifact, version = parts[0], parts[1], parts[2]
    base = os.path.join(mc_dir, "libraries",
                        group.replace(".", "/"), artifact, version)
    jar = os.path.join(base, f"{artifact}-{version}.jar")
    if os.path.exists(jar):
        return jar
    # 带 classifier 的情况, 例如 1.8+ 的 lwjgl 等
    if len(parts) >= 4 and parts[3] not in ("@jar",):
        classifier = parts[3]
        jar2 = os.path.join(base, f"{artifact}-{version}-{classifier}.jar")
        if os.path.exists(jar2):
            return jar2
    return ""


def lib_applies(lib):
    """根据 rules 判断库是否适用于 Windows 平台"""
    rules = lib.get("rules")
    if not rules:
        return True
    allowed = False
    for rule in rules:
        action = rule.get("action", "allow")
        os_name = rule.get("os", {}).get("name", "")
        if os_name in ("windows", ""):
            allowed = (action == "allow")
    return allowed


def extract_natives(lib, mc_dir, dest_dir):
    """解压 natives jar 中的 .dll 文件到 dest_dir"""
    name = lib.get("name", "")
    natives = lib.get("natives", {})
    classifier = ""
    if isinstance(natives, dict):
        classifier = natives.get("windows", "")
    elif isinstance(natives, str):
        classifier = natives
    if not classifier:
        # 尝试从 name 中提取 classifier
        parts = name.split(":")
        if len(parts) >= 4:
            classifier = parts[3]
    if not classifier:
        return
    coord = name
    if classifier and not name.endswith(":" + classifier):
        coord = name + ":" + classifier
    jar_path = maven_lib_path(coord, mc_dir)
    if not jar_path or not os.path.exists(jar_path):
        return
    try:
        import zipfile
        with zipfile.ZipFile(jar_path, "r") as zf:
            for item in zf.namelist():
                if item.endswith(".dll") and "/" not in item:
                    zf.extract(item, dest_dir)
    except Exception:
        pass


def build_launch_command(java, version_id, mc_dir, game_dir, mem_gb, username):
    """构造离线启动命令, 返回 (cmd, error)"""
    version_path = os.path.join(mc_dir, "versions", version_id)
    jar = os.path.join(version_path, version_id + ".jar")
    jsonf = os.path.join(version_path, version_id + ".json")
    main_class = "net.minecraft.client.main.Main"
    args = []
    libs = []
    meta = {}

    if os.path.exists(jsonf):
        try:
            with open(jsonf, encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            meta = {}
        main_class = meta.get("mainClass", main_class)
        # natives 解压目录
        natives_dir = os.path.join(game_dir, "natives", version_id)
        os.makedirs(natives_dir, exist_ok=True)
        for lib in meta.get("libraries", []):
            if not isinstance(lib, dict):
                continue
            name = lib.get("name", "")
            if not name:
                continue
            if not lib_applies(lib):
                continue
            # 处理 natives 库
            if lib.get("natives"):
                extract_natives(lib, mc_dir, natives_dir)
                continue
            p = maven_lib_path(name, mc_dir)
            if p:
                libs.append(p)
    else:
        natives_dir = ""

    if not os.path.exists(jar):
        return None, f"版本 [{version_id}] 缺少启动 jar 文件"

    cp = [jar] + libs
    assets_dir = os.path.join(mc_dir, "assets")
    asset_index = meta.get("assets") or "legacy"
    if not os.path.isdir(os.path.join(assets_dir, "indexes")):
        assets_dir = os.path.join(game_dir, "assets")
    args = [
        "--username", username,
        "--version", version_id,
        "--gameDir", game_dir,
        "--assetsDir", assets_dir,
        "--assetIndex", asset_index,
        "--uuid", "00000000-0000-0000-0000-000000000000",
        "--accessToken", "0",
        "--userType", "legacy",
        "--versionType", "release",
    ]
    cmd = [java, f"-Xmx{mem_gb}G", f"-Xms{max(1, mem_gb // 2)}G"]
    if natives_dir and os.path.isdir(natives_dir):
        cmd.append(f"-Djava.library.path={natives_dir}")
    cmd += ["-cp", os.pathsep.join(cp), main_class] + args
    return cmd, None


class RoundButton(tk.Canvas):
    """自绘圆角按钮, 支持 hover 变色"""

    def __init__(self, parent, text, command, width=180, height=44, radius=14,
                 bg=ACCENT, bg_hover=ACCENT_HOVER, fg="#ffffff", font=None):
        super().__init__(parent, width=width, height=height,
                         bg=parent["bg"], highlightthickness=0, bd=0,
                         cursor="hand2")
        self.cmd = command
        self.bg = bg
        self.bg_hover = bg_hover
        self.radius = radius
        pts = round_rect_points(1, 1, width - 1, height - 1, radius)
        self.shape = self.create_polygon(pts, smooth=True, fill=bg, outline="")
        self.txt = self.create_text(width // 2, height // 2, text=text,
                                    fill=fg, font=font or ("Microsoft YaHei UI", 12, "bold"))
        self.bind("<Enter>", lambda e: self.itemconfig(self.shape, fill=self.bg_hover))
        self.bind("<Leave>", lambda e: self.itemconfig(self.shape, fill=self.bg))
        self.bind("<Button-1>", lambda e: self.cmd())


class RoundCornerBtn(tk.Canvas):
    """右上角圆角的自绘标题栏按钮(与窗口右上角圆角对齐)"""

    def __init__(self, parent, text, command, width=46, height=44, radius=18,
                 bg=BG_HEADER, bg_hover=DANGER, fg=TEXT, font=None):
        super().__init__(parent, width=width, height=height, bg=BG_HEADER,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.cmd = command
        self.bg = bg
        self.bg_hover = bg_hover
        pts = [1 + radius, 1, width - 1, 1, width - 1, 1 + radius,
               width - 1, height - 1, 1, height - 1, 1, 1]
        self.shape = self.create_polygon(pts, smooth=True, fill=bg, outline="")
        self.txt = self.create_text(width // 2, height // 2, text=text,
                                    fill=fg, font=font or ("Segoe UI Symbol", 11))
        self.bind("<Enter>", lambda e: self.itemconfig(self.shape, fill=bg_hover))
        self.bind("<Leave>", lambda e: self.itemconfig(self.shape, fill=bg))
        self.bind("<Button-1>", lambda e: cmd())


class DepartureLauncher:
    def __init__(self):
        enable_dpi_awareness()
        # 设置 AppUserModelID, 让任务栏正确显示图标和名称
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Origin.Launcher.v2")
        except Exception:
            pass
        self.root = tk.Tk()
        self.root.withdraw()  # 立即隐藏, 避免创建时左上角白色闪烁
        self.root.title(APP_NAME)
        # 设置窗口图标(任务栏和标题栏), 必须在 overrideredirect 之前设置
        try:
            self.root.iconbitmap(resource_path("icon.ico"))
        except Exception:
            pass
        try:
            from PIL import Image, ImageTk
            _icon = Image.open(resource_path("icon.png")).resize((64, 64), Image.LANCZOS)
            self._window_icon = ImageTk.PhotoImage(_icon)
            self.root.iconphoto(True, self._window_icon)
        except Exception:
            pass
        self.width, self.height = 850, 530
        self.root.overrideredirect(True)
        self.root.configure(bg=BG_MAIN)
        # 设置窗口大小和位置（从配置文件读取上次位置）
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        saved_pos = self._load_window_position()
        if saved_pos:
            x, y = saved_pos
            x = max(0, min(x, sw - self.width))
            y = max(0, min(y, sh - self.height))
        else:
            x, y = (sw - self.width) // 2, max(10, (sh - self.height) // 2 - 30)
        self.root.geometry(f"{self.width}x{self.height}+{x}+{y}")
        self.root.update_idletasks()  # 确保窗口位置更新
        self.root.withdraw()  # 隐藏窗口，避免启动时白色闪烁
        # 窗口显示后立即设置任务栏样式和圆角区域(缩短延迟, 避免最小化时任务栏图标未就绪)
        self.root.after(10, self._init_window_style)

        self.mc_dir = default_minecraft_dir()
        self.game_dir = self.mc_dir
        self.java_path = shutil_which_java()
        self.proc = None
        self._update_dialog_open = False  # 防止重复弹出更新对话框
        self._checking_update = False  # 防止重复检查更新
        self._message_dialog_open = False  # 防止重复弹出消息对话框
        self._last_check_update_time = 0  # 上次检查更新的时间，用于冷却
        self._update_toast = None
        self._pending_update = None
        # 日志文件路径
        _log_dir = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "DepartureLauncher")
        os.makedirs(_log_dir, exist_ok=True)
        self.log_file = os.path.join(_log_dir, "launcher.log")

        self._build_ui()
        self._load_versions()
        self._log("=" * 50)
        self._log(f"[i] Origin Launcher v{APP_VERSION} 启动")
        # UI 构建完成后再显示窗口，避免启动时白色闪烁
        self.root.after(50, self._show_window)
        # UI重构期间暂时禁用配置加载(变量不存在)
        # self._load_config()
        # self._setup_config_trace()

    # ---------- 工具 ----------
    def _log(self, msg):
        """写入日志到本地文件, 不再显示在界面上"""
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(msg + "\n")
        except Exception:
            pass
        print(msg)

    # ---------- 配置持久化 ----------
    def _config_path(self):
        cfg_dir = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "DepartureLauncher")
        os.makedirs(cfg_dir, exist_ok=True)
        return os.path.join(cfg_dir, "config.json")

    def _load_window_position(self):
        """从配置文件加载上次窗口位置"""
        try:
            p = self._config_path()
            if not os.path.exists(p):
                return None
            with open(p, encoding="utf-8") as f:
                cfg = json.load(f)
            if "window_x" in cfg and "window_y" in cfg:
                return (cfg["window_x"], cfg["window_y"])
        except Exception:
            pass
        return None

    def _save_window_position(self):
        """保存当前窗口位置到配置文件"""
        try:
            x = self.root.winfo_x()
            y = self.root.winfo_y()
            p = self._config_path()
            cfg = {}
            if os.path.exists(p):
                with open(p, encoding="utf-8") as f:
                    cfg = json.load(f)
            cfg["window_x"] = x
            cfg["window_y"] = y
            with open(p, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _save_config(self, *args):
        try:
            cfg = {
                "mem": self.mem_var.get(),
                "username": self.user_var.get(),
                "version": self.ver_var.get(),
                "java_path": self.java_var.get(),
                "game_dir": self.dir_var.get(),
            }
            with open(self._config_path(), "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _load_config(self):
        try:
            p = self._config_path()
            if not os.path.exists(p):
                return
            with open(p, encoding="utf-8") as f:
                cfg = json.load(f)
            if "mem" in cfg:
                self.mem_var.set(cfg["mem"])
                self.mem_label.configure(text=f"{cfg['mem']} GB")
            if "username" in cfg:
                self.user_var.set(cfg["username"])
            if "version" in cfg and cfg["version"]:
                versions = list(self.ver_box["values"])
                if cfg["version"] in versions:
                    self.ver_var.set(cfg["version"])
            if "java_path" in cfg:
                self.java_var.set(cfg["java_path"])
            if "game_dir" in cfg:
                self.dir_var.set(cfg["game_dir"])
        except Exception:
            pass

    def _setup_config_trace(self):
        self.mem_var.trace_add("write", self._save_config)
        self.user_var.trace_add("write", self._save_config)
        self.ver_var.trace_add("write", self._save_config)
        self.java_var.trace_add("write", self._save_config)
        self.dir_var.trace_add("write", self._save_config)

    # ---------- 页面切换 ----------
    # ---------- UI ----------
    def _setup_ttk_style(self):
        """配置 ttk 控件深色主题样式"""
        style = ttk.Style()
        try:
            style.theme_use('clam')
        except Exception:
            pass
        # Combobox 下拉框
        style.configure('TCombobox',
                        fieldbackground='#1a1e1b',
                        background='#1a1e1b',
                        foreground=TEXT,
                        arrowcolor=TEXT_DIM,
                        bordercolor=BORDER,
                        lightcolor=BORDER,
                        darkcolor=BORDER,
                        focusthickness=0,
                        padding=4)
        style.map('TCombobox',
                  fieldbackground=[('readonly', '#1a1e1b')],
                  background=[('readonly', '#1a1e1b')])
        # Scale 滑块
        style.configure('Horizontal.TScale',
                        background=BG_PANEL,
                        troughcolor='#141714',
                        gripcount=0)
        # Scrollbar 滚动条
        style.configure('Vertical.TScrollbar',
                        background='#2a302b',
                        troughcolor=LOGGER_BG,
                        arrowcolor=TEXT_DIM,
                        bordercolor=LOGGER_BG,
                        lightcolor='#2a302b',
                        darkcolor='#2a302b')
        style.map('Vertical.TScrollbar',
                  background=[('active', '#3a423b')])

    def _build_ui(self):
        root = self.root
        # 配置 ttk 深色主题样式
        self._setup_ttk_style()
        # Canvas 背景直接用 BG_MAIN, 窗口圆角由 SetWindowRgn 实现, 无需 colorkey 透明
        self.bg = tk.Canvas(root, width=self.width, height=self.height,
                            bg=BG_MAIN, highlightthickness=0, bd=0)
        self.bg.pack(fill="both", expand=True)
        # 标题栏背景: 顶部圆角(与窗口圆角对齐), 底部绝对平直
        self.bg.create_polygon(round_rect_top_fine(0, 0, self.width, 46, RADIUS),
                               smooth=False, fill=BG_HEADER, outline="")

        # ---- 标题栏(直接绘制在 Canvas 上, 避免 Frame 透明层级问题) ----
        self._make_titlebar()
        self._bind_drag_canvas()

        # 启动时不再自动检查更新
        # self.root.after(2000, lambda: self._check_update(silent=False))

        # ---- 内容区: 左侧边栏 + 右侧主内容区 ----
        self.content = tk.Frame(root, bg=BG_MAIN)
        self.content.place(x=0, y=46, width=self.width, height=self.height - 46)

        # 左侧边栏
        SIDEBAR_W = 180
        self._sidebar_w = SIDEBAR_W
        self._sidebar_collapsed = False
        content_h = self.height - 46
        self.sidebar = tk.Frame(self.content, bg=BG_HEADER, width=SIDEBAR_W)
        self.sidebar.place(x=0, y=0, width=SIDEBAR_W, height=content_h)

        # 侧边栏分隔线
        self.sidebar_divider = tk.Frame(self.content, bg="#e0e0e0", width=1)
        self.sidebar_divider.place(x=SIDEBAR_W, y=0, width=1, height=content_h)

        # 右侧主内容区
        self.main_content = tk.Frame(self.content, bg=BG_MAIN)
        self.main_content.place(x=SIDEBAR_W + 1, y=0, width=self.width - SIDEBAR_W - 1, height=content_h)

        # 侧边栏菜单项
        menu_items = [
            ("👤", "账户"),
            ("🎮", "游戏"),
            ("📥", "下载"),
            ("", "设置"),
            ("", "多人联机"),
            ("💬", "官方群组"),
        ]
        self.menu_labels = []
        item_w = SIDEBAR_W - 16  # padx=8 左右各8
        item_h = 40
        for icon, text in menu_items:
            item_canvas = tk.Canvas(self.sidebar, width=item_w, height=item_h,
                                    bg=BG_HEADER, highlightthickness=0, cursor="hand2")
            item_canvas.pack(fill="x", padx=8, pady=2)
            # 圆角背景(默认透明, hover时显示)
            bg_rect = item_canvas.create_polygon(
                round_rect_fine(0, 0, item_w, item_h, 8, 24), fill="", outline="")
            # 图标
            if text == "设置":
                try:
                    if not hasattr(self, '_settings_icon_img'):
                        from PIL import Image, ImageTk as _IT
                        img = _IT.Image.open(resource_path("settings_icon.png")).resize((20,20), _IT.Image.LANCZOS)
                        self._settings_icon_img = _IT.PhotoImage(img)
                    icon_item = item_canvas.create_image(24, 20, image=self._settings_icon_img)
                except Exception:
                    icon_item = item_canvas.create_text(24, 19, text=icon, fill=TEXT, font=("Microsoft YaHei UI", 12))
            elif text == "多人联机":
                try:
                    if not hasattr(self, '_wifi_icon_img'):
                        from PIL import Image, ImageTk as _IT
                        img = _IT.Image.open(resource_path("wifi_icon.png")).resize((20,20), _IT.Image.LANCZOS)
                        self._wifi_icon_img = _IT.PhotoImage(img)
                    icon_item = item_canvas.create_image(24, 20, image=self._wifi_icon_img)
                except Exception:
                    icon_item = item_canvas.create_text(24, 19, text=icon, fill=TEXT, font=("Microsoft YaHei UI", 12))
            elif text == "官方群组":
                try:
                    if not hasattr(self, '_chat_icon_img'):
                        from PIL import Image, ImageTk as _IT
                        img = _IT.Image.open(resource_path("chat_icon.png")).convert('RGBA')
                        from PIL import ImageFilter
                        alpha = img.split()[3].filter(ImageFilter.MaxFilter(3))
                        img.putalpha(alpha)
                        img = img.resize((20,20), _IT.Image.LANCZOS)
                        self._chat_icon_img = _IT.PhotoImage(img)
                    icon_item = item_canvas.create_image(24, 20, image=self._chat_icon_img)
                except Exception:
                    icon_item = item_canvas.create_text(24, 19, text=icon, fill=TEXT, font=("Microsoft YaHei UI", 12))
            elif text == "账户":
                try:
                    if not hasattr(self, '_sidebar_user_icon_img'):
                        from PIL import Image, ImageTk as _IT
                        img = _IT.Image.open(resource_path("user_icon.png")).convert('RGBA')
                        from PIL import ImageFilter
                        alpha = img.split()[3].filter(ImageFilter.MaxFilter(3))
                        img.putalpha(alpha)
                        img = img.resize((18,18), _IT.Image.LANCZOS)
                        self._sidebar_user_icon_img = _IT.PhotoImage(img)
                    icon_item = item_canvas.create_image(24, 20, image=self._sidebar_user_icon_img)
                except Exception:
                    icon_item = item_canvas.create_text(24, 16, text=icon, fill=TEXT, font=("Microsoft YaHei UI", 12))
            elif text == "下载":
                try:
                    if not hasattr(self, '_download_icon_img'):
                        from PIL import Image, ImageTk as _IT
                        img = _IT.Image.open(resource_path("download_icon.png")).convert('RGBA')
                        from PIL import ImageFilter
                        alpha = img.split()[3].filter(ImageFilter.MaxFilter(3))
                        img.putalpha(alpha)
                        img = img.resize((18,18), _IT.Image.LANCZOS)
                        self._download_icon_img = _IT.PhotoImage(img)
                    icon_item = item_canvas.create_image(24, 20, image=self._download_icon_img)
                except Exception:
                    icon_item = item_canvas.create_text(24, 16, text=icon, fill=TEXT, font=("Microsoft YaHei UI", 12))
            else:
                icon_item = item_canvas.create_text(24, 16, text=icon, fill=TEXT, font=("Microsoft YaHei UI", 12))
            # 文字
            text_y = 21 if text == "多人联机" else 19
            text_item = item_canvas.create_text(52, text_y, text=text, fill=TEXT,
                                                font=("Microsoft YaHei UI", 10), anchor="w")
            # hover 效果
            def on_enter(e, c=item_canvas, bg=bg_rect):
                c.itemconfig(bg, fill="#e0e0e0")
            def on_leave(e, c=item_canvas, bg=bg_rect):
                c.itemconfig(bg, fill="")
            item_canvas.bind("<Enter>", on_enter)
            item_canvas.bind("<Leave>", on_leave)
            item_canvas.bind("<Button-1>", lambda e, t=text: self._on_menu_click(t))
            self.menu_labels.append((item_canvas, bg_rect, icon_item, text_item, text))

        # 阻止窗口接收键盘输入(避免敲击键盘时输入法在窗口上显示文字)
        self.bg.configure(takefocus=0)
        self.root.bind("<Key>", lambda e: "break")
        self.root.bind("<KeyPress>", lambda e: "break")
        # 用 Windows API 彻底禁用输入法
        self.root.after(100, self._disable_ime)
        self.root.after(500, self._detect_accounts_bg)

        # 右下角展开按钮(折叠侧边栏后显示): 抗锯齿圆形黑底白箭头
        from PIL import Image, ImageTk
        btn_size = 48
        import os
        if getattr(sys, 'frozen', False):
            btn_path = os.path.join(sys._MEIPASS, 'expand_btn.png')
        else:
            btn_path = 'expand_btn.png'
        self._expand_img = ImageTk.PhotoImage(Image.open(btn_path))
        self._expand_btn = tk.Label(self.main_content, image=self._expand_img,
                                    bg=BG_MAIN, cursor="hand2", bd=0)
        self._expand_btn.place_forget()
        self._expand_btn.bind("<Button-1>", lambda e: self._back_to_main())

    def _back_to_main(self):
        # 只有在真的账户页面里, 才先取消选中
        if getattr(self, '_in_account_page', False) and hasattr(self, '_account_btns') and self._account_btns:
            selected = False
            for t, (c, r) in self._account_btns.items():
                if c.itemcget(r, 'fill') == '#e0e0e0':
                    selected = True
                    break
            if selected:
                for t, (c, r) in self._account_btns.items():
                    c.itemconfig(r, fill="")
                if hasattr(self, '_account_content') and self._account_content:
                    for w in self._account_content.winfo_children():
                        w.destroy()
                    # 重新显示默认大标题
                    tk.Label(self._account_content, text="// 账户", bg=BG_MAIN, fg="#000000",
                             font=("Microsoft YaHei UI", 24, "bold")).place(x=0, y=-5)
                return
        self._account_cleared = False
        self._in_account_page = False
        for w in self.main_content.winfo_children():
            if w != self._expand_btn:
                w.destroy()
        self._expand_btn.place_forget()
        self._sidebar_collapsed = False
        self._animate_sidebar(-self._sidebar_w, 0, 60)
        if hasattr(self, '_pending_update') and self._pending_update:
            v, c, u = self._pending_update
            self.root.after(300, lambda: self._show_update_toast(v, c, u))

    def _detect_accounts_bg(self):
        """后台检测主流启动器离线账户"""
        import json, os as _os
        self._detected_accounts = []
        mc_dir = _os.path.join(_os.environ.get("APPDATA", ""), ".minecraft")
        lp = _os.path.join(mc_dir, "launcher_profiles.json")
        if _os.path.exists(lp):
            try:
                with open(lp, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for pid, prof in (data.get("profiles") or {}).items():
                    nm = prof.get("name", "").strip()
                    if nm and nm not in [a[0] for a in self._detected_accounts]:
                        self._detected_accounts.append((nm, "官方启动器"))
            except Exception:
                pass
        hmcl_dir = _os.path.join(_os.environ.get("APPDATA", ""), ".hmcl")
        if _os.path.exists(hmcl_dir):
            self._detected_accounts.append(("HMCL 离线账户", "HMCL"))
        pcl_dir = _os.path.join(_os.environ.get("APPDATA", ""), "PCL")
        if _os.path.exists(pcl_dir):
            self._detected_accounts.append(("PCL2 离线账户", "PCL2"))

    def _build_account_page(self):
        """账户页面: 左侧登录方式栏 + 右侧内容"""
        self._in_account_page = True
        self._account_cleared = False
        for w in self.main_content.winfo_children():
            if w != self._expand_btn:
                w.destroy()
        # 左侧栏
        sidebar = tk.Frame(self.main_content, bg="#f8f8f8", width=180)
        sidebar.pack(side="left", fill="y", padx=(0, 0), pady=(0, 0))
        sidebar.pack_propagate(False)
        # 右侧内容区
        self._account_content = tk.Frame(self.main_content, bg=BG_MAIN)
        # 分隔线(在sidebar和content之间)
        tk.Frame(self.main_content, bg="#e0e0e0", width=1).pack(side="left", fill="y")
        self._account_content.pack(side="left", fill="both", expand=True, padx=20, pady=(20, 0))
        # 默认大标题
        tk.Label(self._account_content, text="// 账户", bg=BG_MAIN, fg="#000000",
                 font=("Microsoft YaHei UI", 24, "bold")).place(x=0, y=-5)
        self._account_tabs = ["离线登录", "正版登录", "外置登录"]
        self._account_icons = ["\U0001f464", "\U0001f310", "\U0001f511"]
        item_w = 164
        item_h = 36
        def _select_tab(tab):
            for t, (c, rect) in self._account_btns.items():
                c.itemconfig(rect, fill="#e0e0e0" if t == tab else "")
            for w in self._account_content.winfo_children():
                w.destroy()
            if tab == "离线登录":
                self._build_offline_tab()
                # 渐显动画: 用背景色遮罩从上往下慢慢消失
                self._account_content.update_idletasks()
                content_h = self._account_content.winfo_height()
                overlay = tk.Frame(self._account_content, bg=BG_MAIN)
                overlay.place(x=0, y=0, relwidth=1, height=content_h)
                steps = 60
                def fade_step(i):
                    if i > steps:
                        overlay.destroy()
                        return
                    t = i / steps
                    h = int(content_h * (1 - t))
                    overlay.place_configure(height=h)
                    self.root.after(1, lambda: fade_step(i + 1))
                fade_step(0)
        self._account_btns = {}
        for i, tab in enumerate(self._account_tabs):
            c = tk.Canvas(sidebar, width=item_w, height=item_h, bg="#f8f8f8",
                         highlightthickness=0, cursor="hand2")
            c.pack(padx=8, pady=4)
            rect = c.create_polygon(round_rect_fine(0, 0, item_w, item_h, 8, 24),
                                     fill="", outline="")
            if i == 0:
                from PIL import Image as PILImage, ImageTk as _IT
                import os as _os
                _ip = _os.path.join(sys._MEIPASS, 'disconnect_icon.png') if getattr(sys,'frozen',False) else 'disconnect_icon.png'
                _img = PILImage.open(_ip).convert('RGBA').resize((49,38), PILImage.LANCZOS)
                self._account_offline_icon = _IT.PhotoImage(_img)
                c.create_image(18, item_h//2 - 2, image=self._account_offline_icon)
            else:
                from PIL import Image as PILImage, ImageTk as _IT
                import os as _os
                if i == 2:
                    _ip = _os.path.join(sys._MEIPASS, 'external_icon.png') if getattr(sys,'frozen',False) else 'external_icon.png'
                    _img = PILImage.open(_ip).convert('RGBA').resize((20,20), PILImage.LANCZOS)
                    self._external_icon_img = _IT.PhotoImage(_img)
                    c.create_image(18, item_h//2, image=self._external_icon_img)
                elif i == 1:
                    _ip = _os.path.join(sys._MEIPASS, 'premium_icon.png') if getattr(sys,'frozen',False) else 'premium_icon.png'
                    _img = PILImage.open(_ip).convert('RGBA').resize((35,40), PILImage.LANCZOS)
                    self._premium_icon_img = _IT.PhotoImage(_img)
                    c.create_image(18, item_h//2 - 3, image=self._premium_icon_img)
                else:
                    c.create_text(8, item_h//2, text=self._account_icons[i],
                                  font=("Segoe UI Emoji", 12), anchor="w")
            c.create_text(38, item_h//2, text=tab, fill=TEXT,
                          font=("Microsoft YaHei UI", 10), anchor="w")
            def on_enter(e, cv=c, r=rect, t=tab):
                if t not in [tt for tt, (cc, rr) in self._account_btns.items()
                             if cc.itemcget(rr, 'fill') == '#e0e0e0']:
                    cv.itemconfig(r, fill="#e8e8e8")
            def on_leave(e, cv=c, r=rect, t=tab):
                if t not in [tt for tt, (cc, rr) in self._account_btns.items()
                             if cc.itemcget(rr, 'fill') == '#e0e0e0']:
                    cv.itemconfig(r, fill="")
            c.bind("<Enter>", on_enter)
            c.bind("<Leave>", on_leave)
            c.bind("<Button-1>", lambda e, t=tab: _select_tab(t))
            self._account_btns[tab] = (c, rect)
        # 确保展开按钮在最上层且位置正确
        self._expand_btn.lift()
        content_h = self.height - 46
        ts = 48
        self._expand_btn.place(x=self.width - ts - 10, y=content_h - ts - 10, width=ts, height=ts)

    def _build_offline_tab(self):
        """离线登录内容"""
        f = self._account_content
        tk.Label(f, text="// 创建新账户", bg=BG_MAIN, fg="#000000",
                 font=("Microsoft YaHei UI", 24, "bold")).place(x=0, y=-5)
        tk.Label(f, text="游戏昵称", bg=BG_MAIN, fg=TEXT_DIM,
                 font=("Microsoft YaHei UI", 10)).pack(anchor="w", pady=(40, 4), padx=40)
        self._offline_name_var = tk.StringVar(value=getattr(self, 'current_user', 'Steve'))
        entry = tk.Entry(f, textvariable=self._offline_name_var,
                         font=("Microsoft YaHei UI", 11), width=24, bg="#f0f0f0",
                         relief="flat", highlightthickness=1,
                         highlightbackground="#ddd", highlightcolor="#999")
        entry.pack(anchor="w", pady=(0, 16), padx=40)
        def _confirm():
            name = self._offline_name_var.get().strip()
            if name:
                self.current_user = name
        tk.Label(f, text="登录", bg="#000", fg="white",
                 font=("Microsoft YaHei UI", 10), padx=24, pady=6, cursor="hand2").pack(anchor="w", padx=40)
        entry.bind("<Return>", lambda e: _confirm())

    def _on_menu_click(self, text):
        self._hide_update_toast()
        if text == "账户":
            self._pending_account_page = True
            self._collapse_sidebar()
        else:
            self._collapse_sidebar()

    def _collapse_sidebar(self):
        """折叠侧边栏: 向左滑出消失"""
        if self._sidebar_collapsed:
            return
        self._sidebar_collapsed = True
        self._animate_sidebar(0, -self._sidebar_w, 60)

    def _expand_sidebar(self):
        """展开侧边栏: 从左滑入"""
        if not self._sidebar_collapsed:
            return
        self._sidebar_collapsed = False
        self._animate_sidebar(-self._sidebar_w, 0, 60)
        # 返回主界面时重新显示更新提示
        if hasattr(self, '_pending_update') and self._pending_update:
            v, c, u = self._pending_update
            self.root.after(300, lambda: self._show_update_toast(v, c, u))

    def _animate_sidebar(self, start_x, end_x, steps):
        """侧边栏折叠/展开动画"""
        content_h = self.height - 46
        main_start_w = self.width - self._sidebar_w - 1
        main_end_w = self.width - 1 if end_x < 0 else self.width - self._sidebar_w - 1

        def step(step_idx):
            if step_idx > steps:
                if end_x < 0:
                    if getattr(self, '_pending_account_page', False):
                        self._pending_account_page = False
                        self._build_account_page()
                    self._animate_expand_btn(25)
                else:
                    self._expand_btn.place_forget()
                return
            t = step_idx / steps
            t = 1 - (1 - t) ** 3
            x = int(start_x + (end_x - start_x) * t)
            main_x = x + self._sidebar_w + 1
            main_w = int(main_start_w + (main_end_w - main_start_w) * t)
            self.sidebar.place(x=x, y=0, width=self._sidebar_w, height=content_h)
            self.sidebar_divider.place(x=x + self._sidebar_w, y=0, width=1, height=content_h)
            self.main_content.place(x=main_x, y=0, width=main_w, height=content_h)
            self.root.after(5, lambda: step(step_idx + 1))
        step(0)

    def _animate_expand_btn(self, steps):
        """展开按钮由小变大动画"""
        from PIL import Image as PILImage, ImageTk
        content_h = self.height - 46
        target_size = 48
        x = self.width - target_size - 10
        y = content_h - target_size - 10
        # 预加载原图
        orig = self._expand_img._PhotoImage__photo
        orig_img = Image.open(resource_path('expand_btn.png')).convert('RGBA')
        def btn_step(i):
            if i > steps:
                self._expand_btn.config(image=self._expand_img)
                self._expand_btn.place(x=x, y=y, width=target_size, height=target_size)
                return
            t = i / steps
            t = 1 - (1 - t) ** 3
            sz = max(int(target_size * t), 2)
            resized = orig_img.resize((sz, sz), Image.LANCZOS)
            ph = ImageTk.PhotoImage(resized)
            self._expand_btn._anim_img = ph
            ox = x + (target_size - sz) // 2
            oy = y + (target_size - sz) // 2
            self._expand_btn.config(image=ph)
            self._expand_btn.place(x=ox, y=oy, width=sz, height=sz)
            self.root.after(5, lambda: btn_step(i + 1))
        btn_step(0)
    def _draw_solid_gear(self, canvas, cx, cy, radius, teeth, color):
        """在 Canvas 上绘制实心齿轮图标"""
        import math
        # 绘制齿
        tooth_width = math.pi / teeth
        for i in range(teeth):
            angle = i * 2 * math.pi / teeth
            # 齿的四个角
            x1 = cx + (radius - 3) * math.cos(angle - tooth_width / 2)
            y1 = cy + (radius - 3) * math.sin(angle - tooth_width / 2)
            x2 = cx + radius * math.cos(angle - tooth_width / 2)
            y2 = cy + radius * math.sin(angle - tooth_width / 2)
            x3 = cx + radius * math.cos(angle + tooth_width / 2)
            y3 = cy + radius * math.sin(angle + tooth_width / 2)
            x4 = cx + (radius - 3) * math.cos(angle + tooth_width / 2)
            y4 = cy + (radius - 3) * math.sin(angle + tooth_width / 2)
            canvas.create_polygon(x1, y1, x2, y2, x3, y3, x4, y4, fill=color, outline=color)
        # 绘制中心实心圆
        canvas.create_oval(cx - (radius - 3), cy - (radius - 3),
                          cx + (radius - 3), cy + (radius - 3),
                          fill=color, outline=color)
        # 绘制中心孔（白色小圆，让齿轮看起来更真实）
        canvas.create_oval(cx - 3, cy - 3, cx + 3, cy + 3,
                          fill=canvas["bg"], outline=canvas["bg"])

    def _disable_ime(self):
        """禁用窗口输入法, 防止敲击键盘时 IME 在窗口上显示文字"""
        try:
            # 线程级禁用 IME (比 ImmAssociateContext 更彻底, 解决拼音输入法问题)
            ctypes.windll.imm32.ImmDisableIME(0)
            # 同时禁用顶层窗口和所有子窗口的 IME 上下文
            hwnd = self.root.winfo_id()
            top = ctypes.windll.user32.GetParent(hwnd)
            hwnd = top if top else hwnd
            ctypes.windll.imm32.ImmAssociateContext(hwnd, None)
            def enum_child(hwnd_child, lparam):
                try:
                    ctypes.windll.imm32.ImmAssociateContext(hwnd_child, None)
                except Exception:
                    pass
                return True
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
            ctypes.windll.user32.EnumChildWindows(hwnd, WNDENUMPROC(enum_child), 0)
        except Exception:
            pass

    def _canvas_button(self, x, y, w, h, text, cmd, radius=10, bg=BG_HEADER, hover_bg="#e8e8e8"):
        """抗锯齿图片按钮: 正常态透明, 按下时显示灰色圆"""
        from PIL import Image, ImageTk
        import os
        def _bp(name):
            if getattr(sys, 'frozen', False):
                return os.path.join(sys._MEIPASS, name)
            return name
        if text == "─":  # 最小化
            self._img_min_n = ImageTk.PhotoImage(Image.open(_bp('btn_main_min_normal.png')))
            self._img_min_p = ImageTk.PhotoImage(Image.open(_bp('btn_main_min_pressed.png')))
            btn_img = self.bg.create_image(x, y, anchor="nw", image=self._img_min_n)
            pressed_img = self._img_min_p
        else:  # 关闭
            self._img_close_n = ImageTk.PhotoImage(Image.open(_bp('btn_main_close_normal.png')))
            self._img_close_p = ImageTk.PhotoImage(Image.open(_bp('btn_main_close_pressed.png')))
            btn_img = self.bg.create_image(x, y, anchor="nw", image=self._img_close_n)
            pressed_img = self._img_close_p
        cx, cy = x + w // 2, y + h // 2
        hit_area = self.bg.create_rectangle(x, y, x + w, y + h, fill="", outline="")
        def show_pressed():
            try:
                self.bg.itemconfig(btn_img, image=pressed_img)
            except Exception:
                pass
        def show_normal():
            try:
                normal_img = self._img_min_n if text == "\u2500" else self._img_close_n
                self.bg.itemconfig(btn_img, image=normal_img)
            except Exception:
                pass
        _pressed = [False]
        _was_inside = [False]
        def press(e):
            _pressed[0] = True
            _was_inside[0] = True
            show_pressed()
        def release(e):
            _pressed[0] = False
            _was_inside[0] = False
            show_normal()
            if x <= e.x <= x + w and y <= e.y <= y + h:
                cmd()
        def leave(e):
            if not _pressed[0]:
                show_normal()
        def _btn_motion(e):
            if not _pressed[0]:
                return
            inside = x <= e.x <= x + w and y <= e.y <= y + h
            if inside and not _was_inside[0]:
                show_pressed()
                _was_inside[0] = True
            elif not inside and _was_inside[0]:
                show_normal()
                _was_inside[0] = False
        for item in (hit_area, btn_img):
            self.bg.tag_bind(item, "<Button-1>", press)
            self.bg.tag_bind(item, "<ButtonRelease-1>", release)
            self.bg.tag_bind(item, "<Leave>", leave)
        self.bg.bind("<B1-Motion>", _btn_motion, add="+")
        self.root.bind("<ButtonRelease-1>", lambda e: show_normal(), add="+")
        return (x, y, x + w, y + h)

    def _make_titlebar(self):
        c = self.bg
        # 标题栏图标: 优先用 icon.png, 找不到则用 emoji 兜底
        icon_path = resource_path("icon.png")
        if HAS_PIL and os.path.exists(icon_path):
            icon_img = Image.open(icon_path).resize((24, 24), Image.LANCZOS)
            self.title_icon = ImageTk.PhotoImage(icon_img)
            c.create_image(26, 22, image=self.title_icon)
        else:
            c.create_text(26, 22, text="\u26f3", fill=ACCENT,
                          font=("Segoe UI Emoji", 13), anchor="center")
        # 标题和版本号分开, 动态测量标题宽度避免DPI下重叠
        title_font = ("Microsoft YaHei UI", 11, "bold")
        title_text_id = c.create_text(48, 22, text=APP_NAME, fill=TEXT,
                      font=title_font, anchor="w")
        # 测量标题文字实际宽度
        title_bbox = c.bbox(title_text_id)
        title_w = title_bbox[2] - title_bbox[0] if title_bbox else 100
        version_x = 48 + title_w + 10
        c.create_text(version_x, 23, text=f"v{APP_VERSION}", fill=TEXT_DIM,
                      font=("Microsoft YaHei UI", 9), anchor="w")
        # 右上角按钮组(最小化/关闭, 紧凑布局, 圆角按钮)
        btn_w, btn_h = 40, 38
        btn_y = 4
        self._btn_min_rect = self._canvas_button(
            self.width - btn_w * 2 - 10, btn_y, btn_w, btn_h, "─", self._minimize, radius=12,
            bg=BG_HEADER, hover_bg="#e8e8e8")
        self._btn_close_rect = self._canvas_button(
            self.width - btn_w - 10, btn_y, btn_w, btn_h, "✕", self._close, radius=12,
            bg=BG_HEADER, hover_bg="#cccccc")

    def _bind_drag_canvas(self):
        """拖拽绑定到 Canvas, 排除按钮区域"""
        def in_rect(x, y, rect):
            return rect[0] <= x <= rect[2] and rect[1] <= y <= rect[3]
        def start(e):
            if e.y > 44:
                return
            if in_rect(e.x, e.y, self._btn_min_rect) or in_rect(e.x, e.y, self._btn_close_rect):
                # 在按钮上按下时清除残留的拖拽状态, 防止按钮上移动时误触发窗口拖动
                if hasattr(self, '_drag_dx'):
                    del self._drag_dx
                return
            self._drag_dx = e.x_root - self.root.winfo_x()
            self._drag_dy = e.y_root - self.root.winfo_y()
        def move(e):
            if not hasattr(self, '_drag_dx'):
                return
            x = e.x_root - self._drag_dx
            y = e.y_root - self._drag_dy
            self.root.geometry(f"+{x}+{y}")
        self.bg.bind("<Button-1>", start)
        self.bg.bind("<B1-Motion>", move)

    def _show_window(self):
        """显示窗口（UI 构建完成后调用，避免启动时白色闪烁）"""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass

    def _init_window_style(self):
        """窗口显示后初始化: 设置任务栏样式 + DWM 原生抗锯齿圆角"""
        self._setup_taskbar()
        self._apply_dwm_corner()

    def _get_top_hwnd(self):
        """获取真正的顶层窗口 hwnd (tkinter 的 winfo_id 可能返回子窗口)"""
        hwnd = self.root.winfo_id()
        top = ctypes.windll.user32.GetParent(hwnd)
        return top if top else hwnd

    def _apply_dwm_corner(self):
        """用 Windows 11 DWM 原生抗锯齿圆角, 比 SetWindowRgn 更圆润平滑"""
        try:
            hwnd = self._get_top_hwnd()
            DWMWA_WINDOW_CORNER_PREFERENCE = 33
            DWMWCP_ROUND = 2  # 标准圆角
            pref = ctypes.c_int(DWMWCP_ROUND)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_WINDOW_CORNER_PREFERENCE,
                ctypes.byref(pref), ctypes.sizeof(pref))
        except Exception:
            # Windows 10 不支持 DWM 圆角, 回退到 SetWindowRgn
            pass

    def _apply_dwm_corner_to_window(self, win):
        """给任意 tkinter 窗口应用 DWM 圆角"""
        try:
            hwnd = win.winfo_id()
            top = ctypes.windll.user32.GetParent(hwnd)
            hwnd = top if top else hwnd
            DWMWA_WINDOW_CORNER_PREFERENCE = 33
            DWMWCP_ROUND = 2
            pref = ctypes.c_int(DWMWCP_ROUND)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_WINDOW_CORNER_PREFERENCE,
                ctypes.byref(pref), ctypes.sizeof(pref))
        except Exception:
            pass

    def _create_round_button(self, parent, text, command, bg, fg, width=100, height=32, radius=8, font=None, hover_bg=None):
        """创建圆角按钮(使用 Canvas 绘制)"""
        if font is None:
            font = ("Microsoft YaHei UI", 10, "bold")
        if hover_bg is None:
            hover_bg = bg
        canvas = tk.Canvas(parent, width=width, height=height, bg=parent.cget("bg"),
                          highlightthickness=0, bd=0, cursor="hand2")
        # 绘制圆角矩形背景
        rect = canvas.create_polygon(round_rect_points(0, 0, width, height, radius),
                                     smooth=True, fill=bg, outline="")
        # 绘制文字
        txt = canvas.create_text(width // 2, height // 2, text=text, fill=fg, font=font)
        # 绑定事件
        def on_enter(e):
            canvas.itemconfig(rect, fill=hover_bg)
        def on_leave(e):
            canvas.itemconfig(rect, fill=bg)
        def on_click(e):
            command()
        canvas.bind("<Enter>", on_enter)
        canvas.bind("<Leave>", on_leave)
        canvas.bind("<Button-1>", on_click)
        return canvas

    def _apply_window_rgn(self):
        """用 SetWindowRgn 实现窗口圆角(Windows 10 回退方案)"""
        try:
            hwnd = self._get_top_hwnd()
            r = RADIUS
            hrgn = ctypes.windll.gdi32.CreateRoundRectRgn(0, 0, self.width, self.height, r * 2, r * 2)
            ctypes.windll.user32.SetWindowRgn(hwnd, hrgn, True)
        except Exception:
            pass

    def _setup_taskbar(self):
        """无边框窗口默认不在任务栏显示, 移除 TOOLWINDOW 并添加 APPWINDOW"""
        try:
            hwnd = self._get_top_hwnd()
            GWL_EXSTYLE = -20
            WS_EX_TOOLWINDOW = 0x00000080
            WS_EX_APPWINDOW = 0x00040000
            exstyle = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            exstyle = (exstyle & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW
            ctypes.windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, exstyle)
            # 先隐藏再显示, 强制任务栏立即刷新识别
            SW_HIDE = 0
            SW_SHOW = 5
            ctypes.windll.user32.ShowWindow(hwnd, SW_HIDE)
            ctypes.windll.user32.ShowWindow(hwnd, SW_SHOW)
            # 刷新窗口框架
            SWP_NOMOVE = 0x0002
            SWP_NOSIZE = 0x0001
            SWP_NOZORDER = 0x0004
            SWP_FRAMECHANGED = 0x0020
            ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0,
                                               SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED)
            # 从exe提取高质量大图标, 直接发送WM_SETICON给任务栏
            try:
                import sys
                exe_path = sys.executable if getattr(sys, "frozen", False) else resource_path("icon.ico")
                WM_SETICON = 0x0080
                ICON_BIG = 1
                ICON_SMALL = 0
                # 加载大图标 (32x32或更大)
                hicon_big = ctypes.windll.shell32.ExtractIconW(0, exe_path, 0)
                if hicon_big:
                    ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, hicon_big)
                    ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, hicon_big)
            except Exception:
                pass
        except Exception:
            pass


    # ---- 联网更新 ----
    def _check_update(self, silent=False):
        """检查 GitHub Release 最新版本"""
        # 防止重复检查更新
        if self._checking_update:
            return
        # 检查更新冷却时间（3秒），避免频繁请求触发 GitHub API 速率限制
        import time
        current_time = time.time()
        if current_time - self._last_check_update_time < 3:
            return
        self._last_check_update_time = current_time
        self._checking_update = True

        def worker():
            try:
                req = urllib.request.Request(GITHUB_API, headers={"User-Agent": "OriginLauncher"})
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                latest = data.get("tag_name", "").lstrip("v")
                body = data.get("body", "")
                assets = data.get("assets", [])
                download_url = None
                for a in assets:
                    if a.get("name", "").endswith(".exe"):
                        download_url = a.get("browser_download_url")
                        break
                if not download_url:
                    if not silent:
                        self.root.after(0, lambda: self._show_custom_message("更新", "未找到可下载的 exe 文件", "warning"))
                    return
                if self._compare_version(latest, APP_VERSION) > 0:
                    if silent:
                        self.root.after(0, lambda: self._show_update_toast(latest, body, download_url))
                    else:
                        self.root.after(0, lambda: self._show_update_dialog(latest, body, download_url))
                elif not silent:
                    self.root.after(0, lambda: self._show_custom_message("更新", "当前已是最新版本", "info"))
            except Exception as e:
                self._log("[!] 检查更新失败: " + str(e))
                if not silent:
                    self.root.after(0, lambda err=str(e): self._show_custom_message("更新", "检查更新失败:\n" + err, "error"))
            finally:
                # 检查完成后重置标志位
                self._checking_update = False
        threading.Thread(target=worker, daemon=True).start()

    def _show_update_toast(self, version, changelog, download_url):
        """右上角显示常驻更新提示(深色圆角, 滑入动画)"""
        self._pending_update = (version, changelog, download_url)
        if hasattr(self, '_update_toast') and self._update_toast:
            self._update_toast.destroy()
        toast_w, toast_h = 220, 60
        y = 60
        start_x = self.width
        end_x = self.width - toast_w
        canvas = tk.Canvas(self.root, width=toast_w, height=toast_h,
                           bg=BG_MAIN, highlightthickness=0, bd=0)
        self._update_toast = canvas
        from PIL import Image as PILImage, ImageTk
        import os as _os
        def _tp(name):
            if getattr(sys,'frozen',False): return _os.path.join(sys._MEIPASS,name)
            return name
        self._toast_bg_img = ImageTk.PhotoImage(PILImage.open(_tp('toast_bg.png')))
        canvas.create_image(0,0,anchor="nw",image=self._toast_bg_img)
        canvas.create_text(22, 25, text="\u21bb", fill="white",
                           font=("Segoe UI Symbol", 15), anchor="center")
        canvas.create_text(44, 21, text=f"\u53d1\u73b0\u66f4\u65b0\uff1av{version}", fill="white",
                           font=("Microsoft YaHei UI", 10, "bold"), anchor="w")
        canvas.create_text(44, 40, text="\u70b9\u51fb\u6b64\u5904\u8fdb\u884c\u5347\u7ea7", fill="#999999",
                           font=("Microsoft YaHei UI", 8), anchor="w")
        close_tag = canvas.create_text(toast_w - 14, 14, text="\u2715", fill="#777777",
                                       font=("Microsoft YaHei UI", 8), anchor="center")
        canvas.tag_bind(close_tag, "<Button-1>", lambda e: (setattr(self, '_pending_update', None), self._hide_update_toast()))
        canvas.bind("<Button-1>", lambda e: self._on_toast_click())
        canvas.place(x=start_x, y=y)
        self.root.update_idletasks()
        self._toast_anim_step = 0
        self.root.after(20, lambda: self._animate_toast(start_x, end_x, y))

    def _animate_toast(self, start_x, end_x, y):
        if not hasattr(self, '_update_toast') or not self._update_toast:
            return
        if self._toast_anim_step < 30:
            t = self._toast_anim_step / 30
            t = 1 - (1 - t) ** 3
            x = start_x + (end_x - start_x) * t
            self._update_toast.place(x=int(x), y=y)
            self._toast_anim_step += 1
            self.root.after(5, lambda: self._animate_toast(start_x, end_x, y))

    def _hide_update_toast(self):
        if not hasattr(self, '_update_toast') or not self._update_toast:
            return
        toast_w, toast_h = 220, 60
        y = 60
        end_x = self.width - toast_w
        start_x = self.width
        self._toast_anim_step = 0
        self.root.after(5, lambda: self._animate_toast_out(end_x, start_x, y))

    def _animate_toast_out(self, start_x, end_x, y):
        if not hasattr(self, '_update_toast') or not self._update_toast:
            return
        if self._toast_anim_step < 30:
            t = self._toast_anim_step / 30
            t = 1 - (1 - t) ** 3
            x = start_x + (end_x - start_x) * t
            self._update_toast.place(x=int(x), y=y)
            self._toast_anim_step += 1
            self.root.after(5, lambda: self._animate_toast_out(start_x, end_x, y))
        else:
            self._update_toast.destroy()
            self._update_toast = None

    def _on_toast_click(self):
        if hasattr(self, '_pending_update') and self._pending_update:
            version, changelog, download_url = self._pending_update
            self._show_update_dialog(version, changelog, download_url)

    def _compare_version(self, v1, v2):
        """比较版本号"""
        try:
            a = [int(x) for x in v1.split(".")]
            b = [int(x) for x in v2.split(".")]
            for i in range(max(len(a), len(b))):
                x = a[i] if i < len(a) else 0
                y = b[i] if i < len(b) else 0
                if x > y: return 1
                if x < y: return -1
            return 0
        except Exception:
            return 0

    def _close_update_dialog(self, win):
        """安全关闭更新对话框"""
        self._update_dialog_open = False
        try:
            win.destroy()
        except Exception:
            pass

    def _show_custom_message(self, title, message, msg_type="info"):
        """显示自定义消息对话框(无边框, 与更新对话框风格一致)"""
        # 防止重复弹出消息对话框
        if self._message_dialog_open:
            return
        self._message_dialog_open = True
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry("360x180")
        win.resizable(False, False)
        win.configure(bg=BG_MAIN)
        win.overrideredirect(True)
        win.attributes("-topmost", True)  # 保持对话框在最前面
        win.withdraw()  # 先隐藏，避免位置闪烁
        # 去掉 grab_set，改为非模态，让主界面可以拖动
        # 立即设置居中位置，相对于主界面居中
        try:
            self.root.update_idletasks()
            root_x = self.root.winfo_rootx()
            root_y = self.root.winfo_rooty()
            root_w = self.root.winfo_width()
            root_h = self.root.winfo_height()
            x = root_x + (root_w - 360) // 2
            y = root_y + (root_h - 180) // 2
            win.geometry(f"360x180+{x}+{y}")
        except Exception:
            pass
        win.deiconify()  # 显示对话框
        win.focus_force()

        # 自定义标题栏
        title_bar = tk.Frame(win, bg=BG_HEADER, height=36)
        title_bar.pack(fill="x")
        title_bar.pack_propagate(False)
        tk.Label(title_bar, text=title, bg=BG_HEADER, fg=TEXT,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(side="left", padx=12)
        # 抗锯齿圆形关闭按钮
        from PIL import Image, ImageTk
        import os
        def _btn_path(name):
            if getattr(sys, 'frozen', False):
                return os.path.join(sys._MEIPASS, name)
            return name
        close_normal = ImageTk.PhotoImage(Image.open(resource_path('btn_main_close_normal.png')))
        close_pressed = ImageTk.PhotoImage(Image.open(resource_path('btn_main_close_pressed.png')))
        close_btn = tk.Label(title_bar, image=close_normal, bg=BG_HEADER, cursor="hand2")
        close_btn.image = close_normal
        close_btn.pack(side="right", padx=(0, 2))
        def close_press(e):
            close_btn.config(image=close_pressed)
        def close_release(e):
            close_btn.config(image=close_normal)
            self._close_custom_message(win)
        close_btn.bind("<Button-1>", close_press)
        close_btn.bind("<ButtonRelease-1>", close_release)

        # 拖拽移动
        def start_move(e):
            win._drag_x = e.x
            win._drag_y = e.y
        def do_move(e):
            x = win.winfo_x() + e.x - win._drag_x
            y = win.winfo_y() + e.y - win._drag_y
            win.geometry(f"+{x}+{y}")
        title_bar.bind("<Button-1>", start_move)
        title_bar.bind("<B1-Motion>", do_move)

        # 消息内容(去掉图标，文字居中)
        content_frame = tk.Frame(win, bg=BG_MAIN)
        content_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # 消息文字(居中)
        tk.Label(content_frame, text=message, bg=BG_MAIN, fg=TEXT,
                 font=("Microsoft YaHei UI", 10), wraplength=300, justify="center").pack(expand=True)

        # 确定按钮(圆角)
        btn_frame = tk.Frame(win, bg=BG_MAIN)
        btn_frame.pack(pady=(0, 16))
        ok_btn = self._create_round_button(btn_frame, "确定",
                                           lambda: self._close_custom_message(win),
                                           bg=ACCENT, fg="white", width=100, height=32, radius=8,
                                           hover_bg="#333333")
        ok_btn.pack()
        # 回车键关闭
        win.bind("<Return>", lambda e: self._close_custom_message(win))
        win.bind("<Escape>", lambda e: self._close_custom_message(win))
        # 应用 DWM 圆角
        self._apply_dwm_corner_to_window(win)

    def _close_custom_message(self, win):
        """安全关闭自定义消息对话框"""
        self._message_dialog_open = False
        try:
            win.destroy()
        except Exception:
            pass

    def _debug_log(self, msg):
        try:
            import os, time
            log_path = os.path.join(os.path.expanduser("~"), "launcher_debug.log")
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(time.strftime("%H:%M:%S ") + msg + "\n")
        except:
            pass

    def _show_update_dialog(self, latest, changelog, download_url):
        """显示更新对话框（Toplevel无边框透明，可拖动）"""
        if self._update_dialog_open:
            return
        self._update_dialog_open = True

        win = tk.Toplevel(self.root)
        win.title("")
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        TRANSP = "magenta"
        win.config(bg=TRANSP)
        win.attributes("-transparentcolor", TRANSP)

        # 居中
        sx, sy = self.root.winfo_x(), self.root.winfo_y()
        sw, sh = self.root.winfo_width(), self.root.winfo_height()
        win.geometry("440x400+%d+%d" % (sx + (sw-440)//2, sy + (sh-400)//2))
        win.update_idletasks()
        # SetWindowRgn圆角
        import ctypes
        rgn = ctypes.windll.gdi32.CreateRoundRectRgn(0, 0, 441, 401, 16, 16)
        ctypes.windll.user32.SetWindowRgn(win.winfo_id(), rgn, True)

        # 卡片直接pack，用DWM圆角
        card = tk.Frame(win, bg=BG_MAIN, width=440, height=400,
                        highlightbackground="#e0e0e0", highlightthickness=1)
        card.pack(fill="both", expand=True)
        card.pack_propagate(False)
        self._apply_dwm_corner_to_window(win)

        # 标题栏
        title_bar = tk.Frame(card, bg=BG_HEADER, height=36)
        title_bar.pack(fill="x")
        title_bar.pack_propagate(False)
        tk.Label(title_bar, text="发现新版本", bg=BG_HEADER, fg=TEXT, font=("Microsoft YaHei UI", 10, "bold")).pack(side="left", padx=20)

        close_normal2 = ImageTk.PhotoImage(Image.open(resource_path('btn_main_close_normal.png')))
        close_pressed2 = ImageTk.PhotoImage(Image.open(resource_path('btn_main_close_pressed.png')))
        close_btn2 = tk.Label(title_bar, image=close_normal2, bg=BG_HEADER, cursor="hand2")
        close_btn2.image = close_normal2
        close_btn2.pack(side="right", padx=(0, 2))
        close_btn2.bind("<Button-1>", lambda e: close_btn2.config(image=close_pressed2))
        close_btn2.bind("<ButtonRelease-1>", lambda e: self._close_update_dialog(win))

        # 拖动
        def start_move(e):
            win._x = e.x; win._y = e.y
        def do_move(e):
            x = win.winfo_x() + (e.x - win._x)
            y = win.winfo_y() + (e.y - win._y)
            win.geometry("+%d+%d" % (x, y))
        for w in (title_bar,):
            w.bind("<Button-1>", start_move)
            w.bind("<B1-Motion>", do_move)

        # 内容
        tk.Label(card, text="发现新版本 v" + latest, bg=BG_MAIN, fg=ACCENT,
                 font=("Microsoft YaHei UI", 14, "bold")).pack(anchor="w", padx=20, pady=(16, 4))
        tk.Label(card, text="当前版本 v" + APP_VERSION, bg=BG_MAIN, fg=TEXT_DIM,
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=20)
        tk.Label(card, text="更新日志:", bg=BG_MAIN, fg=TEXT,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=20, pady=(12, 4))
        log_text = tk.Text(card, bg=BG_HEADER, fg=TEXT, bd=0,
                           font=("Microsoft YaHei UI", 9), wrap="word", height=6)
        log_text.pack(fill="x", padx=20)
        log_text.insert("1.0", changelog if changelog else "暂无更新说明")
        log_text.config(state="disabled")

        btn_frame = tk.Frame(card, bg=BG_MAIN)
        btn_frame.pack(pady=16)
        status_var = tk.StringVar(value="")
        progress_frame = tk.Frame(card, bg=BG_MAIN)

        progress_row = tk.Frame(progress_frame, bg=BG_MAIN)
        progress_row.pack(fill="x")
        progress_canvas = tk.Canvas(progress_row, height=8, bg=BG_MAIN, highlightthickness=0)
        progress_canvas.pack(side="left", fill="x", expand=True)
        progress_data = {"value": 0, "max": 100}

        def draw_progress():
            progress_canvas.delete("all")
            w = progress_canvas.winfo_width()
            if w < 10: w = 300
            progress_canvas.create_polygon(round_rect_fine(0, 0, w, 8, 4, 16), fill="#e5e5e5", outline="")
            pct = progress_data["value"] / progress_data["max"] if progress_data["max"] > 0 else 0
            fill_w = int(w * pct)
            if fill_w > 0:
                r = min(4, fill_w // 2)
                progress_canvas.create_polygon(round_rect_fine(0, 0, fill_w, 8, r, 16), fill=ACCENT, outline="")

        class ProgressWrapper:
            def __init__(self, canvas, data, draw_func):
                self.canvas = canvas; self.data = data; self.draw_func = draw_func
            def config(self, **kwargs):
                if "value" in kwargs: self.data["value"] = kwargs["value"]; self.draw_func()
                if "maximum" in kwargs: self.data["max"] = kwargs["maximum"]
        progress = ProgressWrapper(progress_canvas, progress_data, draw_progress)

        def do_download():
            btn_frame.pack_forget()
            progress_frame.pack(fill="x", padx=20, pady=(10, 0))
            progress_canvas.bind("<Configure>", lambda e: draw_progress())
            self.root.after(50, draw_progress)
            tk.Label(progress_frame, textvariable=status_var, bg=BG_MAIN, fg=TEXT_DIM,
                     font=("Microsoft YaHei UI", 9)).pack(anchor="w", pady=(6, 0))
            self._download_update(download_url, win, progress, status_var)

        self._create_round_button(btn_frame, "立即更新", do_download,
                                  bg=ACCENT, fg="white", width=100, height=32, radius=8,
                                  hover_bg="#333333").pack(side="left", padx=8)
        self._create_round_button(btn_frame, "稍后再说", lambda: self._close_update_dialog(win),
                                  bg=BG_HEADER, fg=TEXT, width=100, height=32, radius=8,
                                  font=("Microsoft YaHei UI", 10), hover_bg="#e0e0e0").pack(side="left", padx=8)

    def _download_update(self, url, win, progress, status_var):
        """下载更新文件（先ping测试所有源，选择最快的下载）"""
        import socket
        import time as time_module

        # GitHub 镜像源列表（程序会自动测试可用性，不可用的自动跳过）
        mirrors = [
            ("", "GitHub 官方"),
            ("https://cors.isteed.cc/", "cors.isteed.cc"),
            ("https://ghfast.top/", "ghfast.top"),
            ("https://ghproxy.com/", "ghproxy.com"),
            ("https://mirror.ghproxy.com/", "mirror.ghproxy.com"),
            ("https://gh-proxy.com/", "gh-proxy.com"),
            ("https://github.moeyy.xyz/", "github.moeyy.xyz"),
            ("https://gh.api.99988866.xyz/", "gh.api.99988866.xyz"),
        ]

        def test_download_speed(url, timeout=5, max_bytes=51200):
            """实际下载一小段数据测试真实下载速度，返回速度（KB/s），失败返回 None"""
            try:
                import urllib.request
                # 不使用Range头，直接请求并读取前max_bytes，避免GitHub重定向后不支持Range的问题
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                start = time_module.time()
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    data = resp.read(max_bytes)
                elapsed = time_module.time() - start
                if elapsed > 0 and len(data) > 0:
                    speed_kbps = (len(data) / 1024) / elapsed
                    return speed_kbps
                return None
            except Exception as e:
                return None

        def get_mirror_url(mirror):
            """构造镜像下载 URL"""
            if mirror:
                if url.startswith("https://github.com/"):
                    return mirror + url
            return url

        def get_host_from_url(u):
            """从 URL 中提取主机名"""
            try:
                from urllib.parse import urlparse
                return urlparse(u).hostname
            except:
                return None

        def worker():
            try:
                _worker_inner()
            except Exception as e:
                try:
                    self.root.after(0, lambda: status_var.set(f"出错: {e}"))
                except:
                    pass
                return

        def _worker_inner():
            tmp_path = os.path.join(tempfile.gettempdir(), "OriginLauncher_update.exe")

            # 第一步：ping 测试所有下载源
            self.root.after(0, lambda: status_var.set("正在测试下载源速度..."))
            source_results = []
            for mirror, name in mirrors:
                download_url = get_mirror_url(mirror)
                host = get_host_from_url(download_url)
                if host:
                    speed = test_download_speed(download_url)
                    if speed is not None:
                        # 速度越快，排序值越小（用负速度排序）
                        source_results.append((-speed, mirror, name, download_url))
                        self.root.after(0, lambda n=name, s=speed: status_var.set(
                            f"测试中... {n}: {s:.1f}KB/s"))
                    # 不可用的源直接跳过，不显示
                time_module.sleep(0.1)  # 避免请求过快

            # 按延迟排序，选择最快的
            source_results.sort(key=lambda x: x[0])

            if not source_results:
                self.root.after(0, lambda: self._show_custom_message("更新", "所有下载源均不可用，请检查网络", "error"))
                self.root.after(0, win.destroy)
                return

            # 显示最快的源（速度最快的）
            fastest = source_results[0]
            fastest_speed = -fastest[0]
            self.root.after(0, lambda f=fastest, s=fastest_speed: status_var.set(
                f"选择最快源: {f[2]} ({s:.1f}KB/s)"))
            time_module.sleep(0.5)

            # 第二步：多镜像源并行分块下载
            import threading as threading_mod
            import queue

            # 获取文件总大小
            def get_file_size(url, timeout=10):
                try:
                    req = urllib.request.Request(url, headers={"User-Agent": "OriginLauncher", "Range": "bytes=0-0"})
                    with urllib.request.urlopen(req, timeout=timeout) as resp:
                        content_range = resp.headers.get("Content-Range", "")
                        if content_range and "/" in content_range:
                            return int(content_range.split("/")[-1])
                        return int(resp.headers.get("Content-Length", 0))
                except:
                    return 0

            # 选择可用的镜像源（去掉最慢的1个，最多3个，避免慢源拖慢整体）
            if len(source_results) >= 3:
                available_sources = source_results[:min(3, len(source_results) - 1)]
            else:
                available_sources = source_results[:min(2, len(source_results))]
            num_sources = len(available_sources)

            # 获取文件总大小（从第一个可用源获取）
            total_size = get_file_size(available_sources[0][3])
            if total_size == 0:
                # 如果获取失败，尝试普通请求
                try:
                    req = urllib.request.Request(available_sources[0][3], headers={"User-Agent": "OriginLauncher"})
                    with urllib.request.urlopen(req, timeout=10) as resp:
                        total_size = int(resp.headers.get("Content-Length", 0))
                except:
                    pass

            if total_size == 0:
                self.root.after(0, lambda: self._show_custom_message("更新", "无法获取文件大小，请检查网络", "error"))
                self.root.after(0, win.destroy)
                return

            # 动态分块下载：把文件分成更多小块，快的源下载完后继续下载其他块
            CHUNK_SIZE = 512 * 1024  # 每块0.5MB
            NUM_CHUNKS = max(1, (total_size + CHUNK_SIZE - 1) // CHUNK_SIZE)
            chunks = []
            for i in range(NUM_CHUNKS):
                start = i * CHUNK_SIZE
                end = (i + 1) * CHUNK_SIZE - 1 if i < NUM_CHUNKS - 1 else total_size - 1
                chunks.append((i, start, end))

            # 下载状态
            downloaded_bytes = [0] * NUM_CHUNKS
            download_lock = threading_mod.Lock()
            chunk_queue = queue.Queue()
            for chunk in chunks:
                chunk_queue.put(chunk)
            failed_chunks = []
            chunk_files = [tmp_path + f".part{i}" for i in range(NUM_CHUNKS)]
            active_sources = [0]  # 用列表包装，方便在闭包中修改

            def download_chunk(chunk_idx, start, end, source):
                """下载一个块"""
                _, mirror, name, download_url = source
                part_path = chunk_files[chunk_idx]
                max_retries = 2
                for retry in range(max_retries):
                    try:
                        # 如果是重试，从已下载的位置继续
                        current_start = start
                        if os.path.exists(part_path):
                            current_start = start + os.path.getsize(part_path)
                        if current_start > end:
                            # 检查part文件大小是否等于期望大小
                            expected_size = end - start + 1
                            actual_size = os.path.getsize(part_path)
                            if actual_size == expected_size:
                                # 已经下载完成
                                with download_lock:
                                    downloaded_bytes[chunk_idx] = end - start + 1
                                return True
                            else:
                                # 文件大小不匹配，删除文件并重新下载
                                if os.path.exists(part_path):
                                    try:
                                        os.remove(part_path)
                                    except:
                                        pass
                                current_start = start

                        req = urllib.request.Request(
                            download_url,
                            headers={
                                "User-Agent": "OriginLauncher",
                                "Range": f"bytes={current_start}-{end}"
                            }
                        )
                        with urllib.request.urlopen(req, timeout=20) as resp:
                            # 检查是否支持Range请求（206 Partial Content）
                            if resp.status != 206:
                                # 服务器不支持Range请求，会返回整个文件，跳过这个源
                                if os.path.exists(part_path):
                                    try:
                                        os.remove(part_path)
                                    except:
                                        pass
                                return False
                            mode = "ab" if current_start > start else "wb"
                            with open(part_path, mode) as f:
                                while True:
                                    data = resp.read(16384)
                                    if not data:
                                        break
                                    f.write(data)
                                    with download_lock:
                                        downloaded_bytes[chunk_idx] += len(data)
                        # 验证块大小
                        expected_size = end - start + 1
                        actual_size = os.path.getsize(part_path)
                        if actual_size == expected_size:
                            return True
                        elif actual_size > expected_size:
                            # 文件大小超过期望，说明下载了错误的数据，删除并返回失败
                            if os.path.exists(part_path):
                                try:
                                    os.remove(part_path)
                                except:
                                    pass
                            return False
                        else:
                            # 大小不匹配，重试
                            if os.path.exists(part_path):
                                try:
                                    os.remove(part_path)
                                except:
                                    pass
                            continue
                    except Exception as e:
                        if retry < max_retries - 1:
                            time_module.sleep(1)
                            continue
                        else:
                            return False

            # 块重试计数（避免无限重试）
            chunk_retry_count = {}
            max_chunk_retries = 3

            def worker_thread(source):
                """工作线程：不断从队列中获取块进行下载"""
                while True:
                    try:
                        chunk_idx, start, end = chunk_queue.get_nowait()
                    except queue.Empty:
                        break
                    # 尝试用当前源下载
                    if not download_chunk(chunk_idx, start, end, source):
                        # 失败后重新放回队列，让其他快源接管
                        with download_lock:
                            retry_count = chunk_retry_count.get(chunk_idx, 0) + 1
                            chunk_retry_count[chunk_idx] = retry_count
                            if retry_count < max_chunk_retries * num_sources:
                                chunk_queue.put((chunk_idx, start, end))
                            else:
                                failed_chunks.append((chunk_idx, start, end))
                    chunk_queue.task_done()

            # 启动并行下载（每个源一个工作线程）
            self.root.after(0, lambda: status_var.set(
                f"并行下载中... {num_sources}个镜像源同时下载"))

            threads = []
            for source in available_sources:
                t = threading_mod.Thread(target=worker_thread, args=(source,), daemon=True)
                threads.append(t)
                t.start()

            # 等待所有线程完成，同时更新进度
            while any(t.is_alive() for t in threads):
                time_module.sleep(0.2)
                with download_lock:
                    total_downloaded = sum(downloaded_bytes)
                pct = total_downloaded * 100 // total_size
                self.root.after(0, lambda p=pct: progress.config(value=p))
                self.root.after(0, lambda p=pct, d=total_downloaded, t=total_size: status_var.set(
                    f"并行下载 {p}%  {d/1048576:.1f}/{t/1048576:.1f} MB  ({num_sources}个源)"))

            # 等待所有线程结束
            for t in threads:
                t.join(timeout=5)

            # 检查是否有失败的块
            if failed_chunks:
                # 清理临时文件
                for pf in chunk_files:
                    if os.path.exists(pf):
                        try:
                            os.remove(pf)
                        except:
                            pass
                self.root.after(0, lambda: self._show_custom_message("更新", "部分分块下载失败，请重试", "error"))
                self.root.after(0, win.destroy)
                return

            # 合并所有块（按顺序合并）
            self.root.after(0, lambda: status_var.set("正在合并文件..."))
            try:
                with open(tmp_path, "wb") as out_f:
                    for i in range(NUM_CHUNKS):
                        part_path = chunk_files[i]
                        if os.path.exists(part_path):
                            with open(part_path, "rb") as in_f:
                                while True:
                                    data = in_f.read(1048576)  # 1MB
                                    if not data:
                                        break
                                    out_f.write(data)
                # 验证最终文件大小
                final_size = os.path.getsize(tmp_path)
                if final_size != total_size:
                    raise Exception(f"文件大小不匹配: 期望{total_size}, 实际{final_size}")
            except Exception as e:
                # 清理临时文件
                for pf in chunk_files:
                    if os.path.exists(pf):
                        try:
                            os.remove(pf)
                        except:
                            pass
                if os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except:
                        pass
                self.root.after(0, lambda err=str(e): self._show_custom_message("更新", f"文件合并失败:\n{err}", "error"))
                self.root.after(0, win.destroy)
                return

            # 清理临时块文件
            for pf in chunk_files:
                if os.path.exists(pf):
                    try:
                        os.remove(pf)
                    except:
                        pass

            # 下载成功
            if os.path.getsize(tmp_path) > 1000000:  # 大于 1MB 才算成功
                self.root.after(0, lambda: self._apply_update(tmp_path, win))
                return
            else:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
                self.root.after(0, lambda: self._show_custom_message("更新", "下载文件过小，可能失败", "error"))
                self.root.after(0, win.destroy)
                return
        threading.Thread(target=worker, daemon=True).start()

    def _apply_update(self, new_exe_path, win):
        """应用更新: 生成批处理脚本, 关闭主程序后替换(完全隐藏窗口, 带日志)"""
        try:
            current_exe = sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__)
            if not current_exe.endswith(".exe"):
                self._show_custom_message("更新", "开发模式下无法自动替换，请手动复制文件", "info")
                win.destroy()
                return
            
            # 日志文件路径
            log_path = os.path.join(tempfile.gettempdir(), "update_launcher.log")
            bat_path = os.path.join(tempfile.gettempdir(), "update_launcher.bat")
            
            # 检查是否需要管理员权限（安装在 Program Files 等受保护目录）
            need_admin = False
            protected_dirs = ["Program Files", "Program Files (x86)", "Windows"]
            for pd in protected_dirs:
                if pd.lower() in current_exe.lower():
                    need_admin = True
                    break
            
            # 直接使用完整路径（路径为纯英文+空格，已用引号包裹），
            # 不再使用 GetShortPathNameW —— 现代 Windows/SSD 常禁用 8.3 短文件名，
            # 短路径会导致 del/if exist 失效，更新卡在删除旧文件阶段。
            current_exe_short = current_exe
            new_exe_short = new_exe_path
            
            # 批处理脚本内容（纯英文，线性 goto 结构，避免嵌套括号块解析问题）
            bat_lines = [
                '@echo off',
                'set "LOGFILE=' + log_path + '"',
                'set "CURRENTEXE=' + current_exe_short + '"',
                'set "NEWEXE=' + new_exe_path + '"',
                'set /a retry=0',
                '',
                'echo [%date% %time%] === Update script start === >> "%LOGFILE%"',
                'echo [%date% %time%] Current: %CURRENTEXE% >> "%LOGFILE%"',
                'echo [%date% %time%] New: %NEWEXE% >> "%LOGFILE%"',
                '',
                'REM Check admin rights',
                'net session >nul 2>&1',
                'if %errorlevel%==0 (echo [%date% %time%] Admin: YES >> "%LOGFILE%") else (echo [%date% %time%] Admin: NO >> "%LOGFILE%")',
                '',
                'echo [%date% %time%] Wait 3 seconds... >> "%LOGFILE%"',
                'timeout /t 3 /nobreak >nul',
                '',
                ':retry_delete',
                'set /a retry+=1',
                'if %retry% gtr 30 goto delete_fail',
                'if not exist "%CURRENTEXE%" goto do_copy',
                'echo [%date% %time%] Deleting old file (try %retry%)... >> "%LOGFILE%"',
                'del /f /q "%CURRENTEXE%" >> "%LOGFILE%" 2>&1',
                'if exist "%CURRENTEXE%" goto delete_retry',
                'goto do_copy',
                '',
                ':delete_retry',
                'echo [%date% %time%] Delete still blocked, wait 1s >> "%LOGFILE%"',
                'timeout /t 1 /nobreak >nul',
                'goto retry_delete',
                '',
                ':do_copy',
                'if not exist "%CURRENTEXE%" echo [%date% %time%] Old file gone >> "%LOGFILE%"',
                'echo [%date% %time%] Copying new file... >> "%LOGFILE%"',
                'copy /y "%NEWEXE%" "%CURRENTEXE%" >> "%LOGFILE%" 2>&1',
                'if errorlevel 1 goto copy_fail',
                'echo [%date% %time%] New file copied >> "%LOGFILE%"',
                '',
                'echo [%date% %time%] Removing temp file... >> "%LOGFILE%"',
                'if exist "%NEWEXE%" del /f /q "%NEWEXE%" >> "%LOGFILE%" 2>&1',
                '',
                'echo [%date% %time%] Updating registry version... >> "%LOGFILE%"',
                'reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{B7E3A2C1-4D5F-4A8E-9C2B-1F3D6E8A0B2C}_is1" /v DisplayVersion /d "' + APP_VERSION + '" /f >> "%LOGFILE%" 2>&1',
                '',
                'echo [%date% %time%] Launching new exe... >> "%LOGFILE%"',
                'start "" "%CURRENTEXE%"',
                'timeout /t 3 /nobreak >nul',
                '',
                'echo [%date% %time%] === Update script done === >> "%LOGFILE%"',
                'goto cleanup_self',
                '',
                ':copy_fail',
                'echo [%date% %time%] ERROR: copy failed >> "%LOGFILE%"',
                'goto cleanup_self',
                '',
                ':delete_fail',
                'echo [%date% %time%] ERROR: cannot delete old file after 30 tries >> "%LOGFILE%"',
                '',
                ':cleanup_self',
                'del /f /q "%~f0"',
                'exit /b 0',
            ]
                        # 写入批处理脚本（纯 ASCII，无 BOM，避免 cmd 解析失败）
            with open(bat_path, "w", encoding="ascii") as f:
                f.write("\r\n".join(bat_lines) + "\r\n")
            
            self._log("[更新] 已生成更新脚本: " + bat_path)
            self._log("[更新] 日志文件: " + log_path)
            self._log("[更新] 当前程序短路径: " + current_exe_short)
            self._log("[更新] 新程序短路径: " + new_exe_short)
            
            # 先释放模态，避免卡死
            self._close_update_dialog(win)
            self._hide_update_toast()
            
            # 启动批处理脚本(完全隐藏窗口)
            if need_admin:
                self._log("[更新] 需要管理员权限，使用 ShellExecuteW 提升方式启动")
                result = ctypes.windll.shell32.ShellExecuteW(None, "runas", bat_path, 
                    "", None, 0)  # 0 = SW_HIDE
                self._log("[更新] ShellExecuteW 返回值: " + str(result))
                if result <= 32:
                    self._log("[更新] 警告: ShellExecuteW 可能失败，返回值 <= 32")
            else:
                self._log("[更新] 普通权限启动更新脚本")
                subprocess.Popen([bat_path],
                               creationflags=subprocess.CREATE_NO_WINDOW)
            
            # 给脚本一点时间启动，再退出主程序
            import time
            time.sleep(1.0)
            self._log("[更新] 主程序即将退出")
            self._close()
        except Exception as e:
            self._log("[更新] 应用更新失败: " + str(e))
            self._show_custom_message("更新", "应用更新失败:\n" + str(e), "error")
            self._close_update_dialog(win)

    def _minimize(self):
        # 用 ShowWindow SW_MINIMIZE 最小化, CloseWindow 对无边框窗口会完全隐藏
        hwnd = self._get_top_hwnd()
        SW_MINIMIZE = 6
        ctypes.windll.user32.ShowWindow(hwnd, SW_MINIMIZE)

    def _close(self):
        # 保存窗口位置
        self._save_window_position()
        if self.proc and self.proc.poll() is None:
            if not messagebox.askyesno("退出", "游戏正在运行, 确定退出启动器吗?"):
                return
            try:
                self.proc.terminate()
            except Exception:
                pass
        # 安全退出: 先隐藏窗口, 取消绑定, 再退出 mainloop, 避免 Tcl alloc 错误
        try:
            self.root.withdraw()
            self.bg.unbind_all("<Button-1>")
            self.bg.unbind_all("<B1-Motion>")
            self.root.quit()
            self.root.destroy()
        except Exception:
            pass
        # 强制退出, 跳过 Tcl 清理阶段
        import os
        os._exit(0)

    # ---- 内容区 ----
    def _build_hero(self):
        c = self.content
        tk.Label(c, text="Origin Launcher", bg=BG_MAIN, fg=TEXT,
                 font=("Microsoft YaHei UI", 22, "bold")).pack(anchor="w")
        tk.Label(c, text="简洁 · 圆角 · 轻量的 Minecraft 启动器  |  离线启动本地版本",
                 bg=BG_MAIN, fg=TEXT_DIM,
                 font=("Microsoft YaHei UI", 10)).pack(anchor="w", pady=(4, 14))

    def _build_settings_panel(self):
        c = self.content
        panel = tk.Frame(c, bg=BG_PANEL)
        panel.pack(fill="x")

        # 两列栅格: 版本 | 用户名 | 内存 ; Java | 目录
        row1 = tk.Frame(panel, bg=BG_PANEL)
        row1.pack(fill="x", padx=22, pady=(18, 8))
        self._field_row(row1, "游戏版本", 0, with_refresh=True)
        self._field_row(row1, "用户名", 1, is_entry=True)

        row2 = tk.Frame(panel, bg=BG_PANEL)
        row2.pack(fill="x", padx=22, pady=8)
        self._field_row(row2, "内存分配", 0, is_mem=True)
        self._field_row(row2, "Java 路径", 1, is_path=True)

        row3 = tk.Frame(panel, bg=BG_PANEL)
        row3.pack(fill="x", padx=22, pady=(8, 18))
        self._field_row(row3, "游戏目录", 0, is_dir=True)

    def _field_row(self, parent, label, col, is_entry=False, is_mem=False,
                   is_path=False, is_dir=False, with_refresh=False):
        pad = 8
        w = (self.width - 60 - 44) // 2 - 8
        f = tk.Frame(parent, bg=BG_PANEL)
        f.grid(row=0, column=col, sticky="ew", padx=(0 if col == 0 else 16, 0), pady=0)
        tk.Label(f, text=label, bg=BG_PANEL, fg=TEXT_DIM, width=8, anchor="w",
                 font=("Microsoft YaHei UI", 10)).pack(side="left")
        if is_mem:
            self.mem_var = tk.IntVar(value=4)
            self.mem_label = tk.Label(f, text="4 GB", bg=BG_PANEL, fg=ACCENT, width=6,
                                      font=("Microsoft YaHei UI", 10, "bold"))
            self.mem_label.pack(side="right", padx=(0, 4))
            self.mem_scale = ttk.Scale(f, from_=1, to=16, variable=self.mem_var,
                                       command=lambda v: self.mem_label.configure(
                                           text=f"{int(float(v))} GB"))
            self.mem_scale.pack(side="right", fill="x", expand=True, padx=(6, 10))
        elif is_entry:
            self.user_var = tk.StringVar(value=DEFAULT_USER)
            self.user_entry = self._entry(f)
            self.user_entry.configure(textvariable=self.user_var)
            self.user_entry.pack(side="left", fill="x", expand=True)
        elif is_path:
            self.java_var = tk.StringVar(value=self.java_path or "")
            self.java_entry = self._entry(f)
            self.java_entry.configure(textvariable=self.java_var)
            self.java_entry.pack(side="left", fill="x", expand=True)
            self._mini_btn(f, "浏览", lambda: self._pick_java()).pack(side="left", padx=(6, 0))
        elif is_dir:
            self.dir_var = tk.StringVar(value=self.mc_dir)
            self.dir_entry = self._entry(f)
            self.dir_entry.configure(textvariable=self.dir_var)
            self.dir_entry.pack(side="left", fill="x", expand=True)
            self._mini_btn(f, "浏览", lambda: self._pick_dir()).pack(side="left", padx=(6, 0))
        elif with_refresh:
            self.ver_var = tk.StringVar()
            self.ver_box = ttk.Combobox(f, textvariable=self.ver_var,
                                        state="readonly", font=("Microsoft YaHei UI", 10))
            self.ver_box.pack(side="left", fill="x", expand=True)
            self._mini_btn(f, "刷新", self._load_versions).pack(side="left", padx=(6, 0))

    def _entry(self, parent):
        e = tk.Entry(parent, bg="#ffffff", fg=TEXT, insertbackground=TEXT,
                     relief="flat", bd=0, highlightthickness=1,
                     highlightbackground=BORDER, highlightcolor=ACCENT,
                     font=("Microsoft YaHei UI", 10))
        return e

    def _mini_btn(self, parent, text, cmd):
        b = tk.Label(parent, text=text, bg="#e0e0e0", fg=TEXT, padx=10, pady=3,
                     cursor="hand2", font=("Microsoft YaHei UI", 9))
        b.bind("<Enter>", lambda e: b.configure(bg="#d0d0d0"))
        b.bind("<Leave>", lambda e: b.configure(bg="#e0e0e0"))
        b.bind("<Button-1>", lambda e: cmd())
        return b

    def _build_launch_row(self):
        c = self.content
        # 启动按钮居中
        row = tk.Frame(c, bg=BG_MAIN)
        row.pack(fill="x", pady=(28, 0))
        self.launch_btn = RoundButton(row, "启 动 游 戏", self._launch_game,
                                      width=240, height=52, radius=18,
                                      font=("Microsoft YaHei UI", 14, "bold"))
        self.launch_btn.pack()
        # 状态标签
        self.status_lbl = tk.Label(row, text="就绪", bg=BG_MAIN, fg=TEXT_DIM,
                                   font=("Microsoft YaHei UI", 10))
        self.status_lbl.pack(pady=(10, 0))

    def _build_logger(self):
        c = self.content
        tk.Label(c, text="启动日志", bg=BG_MAIN, fg=TEXT_DIM,
                 font=("Microsoft YaHei UI", 10)).pack(anchor="w", pady=(14, 4))
        frame = tk.Frame(c, bg=LOGGER_BG)
        frame.pack(fill="both", expand=True)
        self.log_txt = tk.Text(frame, bg=LOGGER_BG, fg="#1a1a1a", insertbackground=TEXT,
                               relief="flat", bd=0, wrap="word",
                               font=("Consolas", 9), state="disabled",
                               padx=10, pady=8)
        sb = ttk.Scrollbar(frame, command=self.log_txt.yview)
        self.log_txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log_txt.pack(side="left", fill="both", expand=True)

    # ---------- 逻辑 ----------
    def _pick_java(self):
        p = filedialog.askopenfilename(title="选择 java.exe",
                                       filetypes=[("Java", "java.exe"), ("All", "*.*")])
        if p:
            self.java_var.set(p)
            self.java_path = p

    def _pick_dir(self):
        p = filedialog.askdirectory(title="选择游戏目录")
        if p:
            self.dir_var.set(p)

    def _load_versions(self):
        """扫描本地版本(UI重构期间只扫描并记录日志, 不更新界面)"""
        mc = self.mc_dir
        versions = scan_versions(mc)
        self._log(f"[i] 扫描游戏目录: {mc}")
        if versions:
            self._log(f"[i] 可用版本: {', '.join(versions[:8])}{'...' if len(versions) > 8 else ''}")
        else:
            self._log("[w] 未找到任何版本, 请确认 .minecraft/versions 目录")

    def _launch_game(self):
        if self.proc and self.proc.poll() is None:
            self._log("[!] 游戏已在运行")
            return
        version = self.ver_var.get()
        java = self.java_var.get().strip() or shutil_which_java()
        game_dir = self.dir_var.get().strip() or self.mc_dir
        mem = self.mem_var.get()
        user = self.user_var.get().strip() or DEFAULT_USER
        if not version:
            messagebox.showwarning("提示", "请先选择游戏版本")
            return
        if not java or not os.path.exists(java):
            messagebox.showwarning("提示", "未找到 Java, 请手动指定 java.exe 路径")
            return

        self.status_lbl.configure(text="正在启动...", fg=ACCENT)
        threading.Thread(target=self._launch_worker,
                         args=(java, version, self.mc_dir, game_dir, mem, user),
                         daemon=True).start()

    def _launch_worker(self, java, version, mc_dir, game_dir, mem, user):
        cmd, err = build_launch_command(java, version, mc_dir, game_dir, mem, user)
        if err:
            self._log(f"[!] {err}")
            self.status_lbl.configure(text="启动失败", fg=DANGER)
            return
        self._log("[i] 命令: " + " ".join(cmd))
        try:
            self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT,
                                         text=True, encoding="utf-8", errors="replace",
                                         cwd=game_dir, creationflags=0x08000000)
            self._log(f"[i] 游戏进程已启动 (PID {self.proc.pid})")
            for line in self.proc.stdout:
                self._log(line.rstrip())
            code = self.proc.wait()
            self._log(f"[i] 游戏退出, 返回码 {code}")
            self.status_lbl.configure(text="游戏已退出", fg=TEXT_DIM)
        except Exception as e:
            self._log(f"[!] 启动异常: {e}")
            self.status_lbl.configure(text="启动失败", fg=DANGER)

    def run(self):
        self.root.mainloop()


def shutil_which_java():
    try:
        import shutil
        p = shutil.which("java")
        return p or ""
    except Exception:
        return ""


def main():
    app = DepartureLauncher()
    app.run()


if __name__ == "__main__":
    main()

















































